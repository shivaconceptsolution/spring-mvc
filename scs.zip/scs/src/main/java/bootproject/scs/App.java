package bootproject.scs;

/**
 * Hello world!
 *
 */
import org.springframework.boot.SpringApplication;
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(HelloController.class,args);	
    }
}
