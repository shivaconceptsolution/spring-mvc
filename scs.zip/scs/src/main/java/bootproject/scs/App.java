package bootproject.scs;


import org.springframework.boot.SpringApplication;
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(EmployeeController.class,args);	
    }
}
