package bootproject.scs;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
@ComponentScan
@EnableAutoConfiguration
@RestController
@RequestMapping(path = "/empl")
public class EmployeeController {
	@Autowired
	  private EmpDao employeeDao;
	 @GetMapping(
		        path = "/",
		        produces = "application/json")
		  
		    public Employees getEmployees()
		    {
		  
		        return employeeDao.getAllEmployees();
		    }
	 @PostMapping(
		        path = "/",
		        consumes = "application/json",
		        produces = "application/json")
		  
		    public ResponseEntity<String> addEmployee(
		        @RequestBody Emp employee)
		    {
		  
		        employeeDao.addEmployee(employee);
		  
		        return ResponseEntity.ok("{message:'succes'}");
		           
		    }
}
