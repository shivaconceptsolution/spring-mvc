package controllers;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Add;
import models.Admin;
@Controller
public class AdminController {
	@RequestMapping("login")
  public ModelAndView login()
  {
	  return new ModelAndView("login","command",new Admin());
  }
	@RequestMapping("loginlogic")
	  public ModelAndView loginlogic(@ModelAttribute("spring-mvc-hello")Admin obj,ModelMap mp)
	  {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
        SessionFactory sf = cfg.buildSessionFactory();
        Session sess = sf.openSession();
        Query q  = sess.createQuery("from Admin s where s.username=? and password=?");
        q.setString(0,obj.getUsername());
        q.setString(1,obj.getPassword());
        List lst = q.list();
        if(lst.size()>0)
        {
		  return new ModelAndView("redirect:showsi.do");
        }
        else
        {
        	 mp.addAttribute("key","Invalid Userid and Password");
        	 return new ModelAndView("login","command",new Admin());
        }
	  }
}
