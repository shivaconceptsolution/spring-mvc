package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.Transaction;

import org.hibernate.cfg.Configuration;
import models.SI;
@Controller
public class SIController {

	@RequestMapping("si")
	public ModelAndView siLoad()
	{
		return new ModelAndView("siindex","command",new SI());
	}
	@RequestMapping("silogic")
	public ModelAndView siLoad(@ModelAttribute("spring-mvc-hello")SI obj, ModelMap mp)
	{
		float si = (obj.getP()*obj.getR()*obj.getT())/100;
		Configuration cfg = new Configuration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session sess = sf.openSession();

		Transaction tx= sess.beginTransaction();
		sess.save(obj);

		tx.commit();

		sess.close();
		ModelAndView obj1 =  new ModelAndView("siindex","command",new SI());
		//obj1.addObject("key",si);
		mp.addObject("key",si);
		return obj1;
	}
	
}
