package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HospitalContoller {
	@RequestMapping("home")
	   public ModelAndView home()
	   {
		     return new ModelAndView("guest");
		   
	   }
	@RequestMapping("about")
	   public ModelAndView about()
	   {
		     return new ModelAndView("guest");
		   
	   }
	@RequestMapping("services")
	   public ModelAndView services()
	   {
		     return new ModelAndView("guest");
		   
	   }
	@RequestMapping("pricing")
	   public ModelAndView pricing()
	   {
		     return new ModelAndView("pricing");
		   
	   }
	@RequestMapping("contact")
	   public ModelAndView contact()
	   {
		     return new ModelAndView("contact");
		   
	   }
}
