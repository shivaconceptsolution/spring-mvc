package controllers;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Add;

@Controller
public class AdditionController {
	@RequestMapping("addition")
   public ModelAndView addition()
   {
	     return new ModelAndView("addition","command",new Add());
	   
   }
   
	@RequestMapping("additionlogic")
	   public ModelAndView additionmethod(@ModelAttribute("spring-mvc-hello")Add obj)
	   {
		     int c = obj.getNum1() + obj.getNum2();
		     return new ModelAndView("result","key",c);
		   
	   }
}
